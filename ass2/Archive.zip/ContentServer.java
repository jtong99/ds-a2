import java.util.*;

import com.google.gson.JsonObject;

public class ContentServer {
    private Lamport localClock;
    private SocketServer socketServer;
    private final String requestID;
    private JsonObject data;

    public ContentServer(SocketServer socket) {
        this.requestID = UUID.randomUUID().toString();
        this.socketServer = socket;
        this.localClock = new Lamport();
    }

    public boolean isLoadFileSuccess(String filePath) {
        try {
            String fileContent = JsonHandling.read(filePath);
            this.data = JsonHandling.convertJSON(fileContent);
            return true;
        } catch (Exception e) {
            System.out.println("Error on loading file " + e.getMessage());
            return false;
        }
    }

    public void uploadData() {
        
        try {
            this.socketServer.initializeSocket("localhost", 4000);
            String dataString = JsonHandling.prettier(this.data);
            
            String putRequest = "PUT /weather.json HTTP/1.1\r\n" +
                            "Content-Length: " + dataString.length() + "\r\n" +
                            "\r\n" +
                            dataString;
            String response = this.socketServer.sendAndReceiveData("localhost", 4000, putRequest, true);
            System.out.println("Response data: ");
            System.out.println(response);
            System.out.println();
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("Error while connecting to the server: " + e.getMessage());
            System.out.println("Retry in 15 second.");
        }
    }

    public static void main(String[] args) {
        int port;
        try {
            port = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("No port provided");
            return;
        }

        String file = args[2];

        SocketServer socketHandler = new SocketServer();
        ContentServer server = new ContentServer(socketHandler);

        if (!server.isLoadFileSuccess(file)) {
            System.out.println("Error: Failed to load data from " + file);
            return;
        }
        server.uploadData();

        Thread monitorThread = new Thread(() -> {
            Scanner scanner = new Scanner(System.in);
            while (true) {
                String input = scanner.nextLine();
                if ("SHUTDOWN".equalsIgnoreCase(input)) {
                    // shutdown();
                    scanner.close();
                    break;
                }
            }
        });
        monitorThread.start();
    }
}
