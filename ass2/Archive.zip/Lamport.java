public class Lamport {
    private int time;

    /**
     * Constructs a new LamportClock initialized to zero.
     */
    public Lamport() {
        this.time = 0;
    }

    /**
     * Increase the clock
     */
    public void increase() {
        time++;
    }

    /**
     * sendMessage.
     * @return The current value of the clock after sendMessage.
     */
    public int sendMessage() {
        return ++time;
    }

    /**
     * Adjusts the clock based on the timestamp of a received message.
     * The clock is set to the maximum of its current value and the received timestamp,
     * and then it's incremented by one.
     * @param receivedTimestamp The timestamp of the received message.
     */
    public void adjust(int receivedTimestamp) {
        time = Math.max(time, receivedTimestamp) + 1;
    }

    /**
     * Retrieves the current value of the clock.
     * @return The current time of the clock.
     */
    public int getTime() {
        return time;
    }

    /**
     * Sets the clock to a specific value.
     * Caution: Use this method judiciously as it can disrupt the causal ordering.
     * @param newValue The new value to set the clock to.
     */
    public void setClock(int newValue) {
        time = newValue;
    }

    /**
     * Provides a string representation of the LamportClock.
     * @return A string representation of the clock's current time.
     */
    @Override
    public String toString() {
        return "LamportClock [time=" + time + "]";
    }
}
